import { redirect } from "next/navigation";

export default function PricingIndexPage() {
  redirect("/pricing/labor-rates");
}
