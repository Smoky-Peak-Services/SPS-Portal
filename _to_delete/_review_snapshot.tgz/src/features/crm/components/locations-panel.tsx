"use client";

import { useRouter } from "next/navigation";
import { useMemo, useState, useTransition } from "react";
import {
  createServiceLocation,
  deleteServiceLocation,
} from "@/features/crm/actions";
import { AddressAutocomplete } from "@/features/crm/components/address-autocomplete";
import { MapTile } from "@/features/crm/components/map-tile";
import {
  classificationLabel,
  locationDisplayName,
  serviceLineLabel,
  type ServiceLine,
  type ServiceLocationClassification,
} from "@/features/crm/service-location";
import { FormSelect } from "@/components/patterns/form-select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { DataTableShell } from "@/components/patterns/data-table-shell";

const CLASSIFICATION_OPTIONS = [
  { value: "RESIDENTIAL", label: "Residential" },
  { value: "COMMERCIAL", label: "Commercial" },
];

type Location = {
  id: string;
  siteName: string | null;
  classification: "RESIDENTIAL" | "COMMERCIAL";
  serviceLines: ServiceLine[];
  line1: string;
  line2: string | null;
  city: string;
  region: string;
  postalCode: string;
  latitude: number | null;
  longitude: number | null;
  bedrooms: number | null;
  bathrooms: number | null;
};

export function LocationsPanel({
  customerId,
  locations,
  canWrite,
  showCabinFields,
}: {
  customerId: string;
  locations: Location[];
  canWrite: boolean;
  showCabinFields: boolean;
}) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [classification, setClassification] =
    useState<ServiceLocationClassification>("RESIDENTIAL");
  const [isChecked, setIsChecked] = useState(true);
  const [cabinChecked, setCabinChecked] = useState(false);

  const isCommercial = classification === "COMMERCIAL";

  const formKey = useMemo(
    () => `${classification}:${isCommercial ? "is" : "flex"}`,
    [classification, isCommercial],
  );

  function onClassificationChange(next: string) {
    const value = next as ServiceLocationClassification;
    setClassification(value);
    if (value === "COMMERCIAL") {
      setIsChecked(true);
      setCabinChecked(false);
    }
  }

  return (
    <div className="space-y-6">
      <DataTableShell>
        <table className="w-full text-left text-sm">
          <thead className="border-b bg-muted/40 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Site</th>
              <th className="px-4 py-3">Classification</th>
              <th className="px-4 py-3">Service lines</th>
              <th className="px-4 py-3">Address</th>
              {canWrite ? (
                <th className="px-4 py-3 text-right">Actions</th>
              ) : null}
            </tr>
          </thead>
          <tbody>
            {locations.map((loc) => (
              <tr key={loc.id} className="border-b border-border/60">
                <td className="px-4 py-3">{locationDisplayName(loc)}</td>
                <td className="px-4 py-3">
                  {classificationLabel(loc.classification)}
                </td>
                <td className="px-4 py-3">
                  {loc.serviceLines.map(serviceLineLabel).join(", ")}
                </td>
                <td className="px-4 py-3">
                  {loc.line1}, {loc.city}, {loc.region} {loc.postalCode}
                </td>
                {canWrite ? (
                  <td className="px-4 py-3 text-right">
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      disabled={pending}
                      onClick={() => {
                        start(async () => {
                          await deleteServiceLocation({ id: loc.id });
                          router.refresh();
                        });
                      }}
                    >
                      Delete
                    </Button>
                  </td>
                ) : null}
              </tr>
            ))}
          </tbody>
        </table>
      </DataTableShell>

      {locations.length > 0 ? (
        <div className="grid gap-4 sm:grid-cols-2">
          {locations.map((loc) => (
            <div
              key={`map-${loc.id}`}
              className="space-y-2 rounded-md border border-border p-3"
            >
              <p className="text-sm font-medium">{locationDisplayName(loc)}</p>
              <p className="text-xs text-muted-foreground">
                {loc.line1}, {loc.city}, {loc.region} {loc.postalCode}
              </p>
              <MapTile
                lat={loc.latitude}
                lon={loc.longitude}
                label={locationDisplayName(loc)}
              />
              {loc.latitude == null || loc.longitude == null ? (
                <p className="text-xs text-muted-foreground">
                  No map yet. Edit or re-save with address lookup to geocode.
                </p>
              ) : null}
            </div>
          ))}
        </div>
      ) : null}

      {canWrite ? (
        <form
          key={formKey}
          className="grid gap-3 rounded-md border border-border p-4 sm:grid-cols-2"
          onSubmit={(e) => {
            e.preventDefault();
            setError(null);
            const fd = new FormData(e.currentTarget);
            const serviceLines = isCommercial
              ? (["INTEGRATED_SYSTEMS"] as const)
              : (fd.getAll("serviceLines") as string[]);
            start(async () => {
              const result = await createServiceLocation({
                customerId,
                siteName: fd.get("siteName"),
                classification,
                serviceLines:
                  serviceLines.length > 0
                    ? serviceLines
                    : ["INTEGRATED_SYSTEMS"],
                line1: fd.get("line1"),
                line2: fd.get("line2"),
                city: fd.get("city"),
                region: fd.get("region"),
                postalCode: fd.get("postalCode"),
                latitude: fd.get("latitude"),
                longitude: fd.get("longitude"),
                bedrooms: fd.get("bedrooms") || null,
                bathrooms: fd.get("bathrooms") || null,
              });
              if (!result.ok) {
                setError(result.error);
                return;
              }
              setClassification("RESIDENTIAL");
              setIsChecked(true);
              setCabinChecked(false);
              e.currentTarget.reset();
              router.refresh();
            });
          }}
        >
          <Input name="siteName" placeholder="Site name" />
          <FormSelect
            name="classification"
            label="Classification"
            options={CLASSIFICATION_OPTIONS}
            value={classification}
            onValueChange={onClassificationChange}
            required
          />
          <div className="sm:col-span-2">
            <AddressAutocomplete
              names={{
                line1: "line1",
                line2: "line2",
                city: "city",
                region: "region",
                postal: "postalCode",
                lat: "latitude",
                lon: "longitude",
              }}
              required
            />
          </div>
          <div className="flex flex-col gap-2 text-sm sm:col-span-2">
            <span className="text-muted-foreground">Service lines</span>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                name="serviceLines"
                value="INTEGRATED_SYSTEMS"
                checked={isCommercial ? true : isChecked}
                disabled={isCommercial}
                onChange={(e) => setIsChecked(e.target.checked)}
              />
              Integrated Systems
            </label>
            <label
              className={`flex items-center gap-2 ${
                isCommercial ? "opacity-50" : ""
              }`}
            >
              <input
                type="checkbox"
                name="serviceLines"
                value="CABIN_SERVICES"
                checked={isCommercial ? false : cabinChecked}
                disabled={isCommercial}
                onChange={(e) => setCabinChecked(e.target.checked)}
              />
              Cabin Services
            </label>
            {isCommercial ? (
              <p className="text-xs text-muted-foreground">
                Commercial sites are always Integrated Systems only.
              </p>
            ) : null}
          </div>
          {showCabinFields && !isCommercial ? (
            <>
              <Input
                name="bedrooms"
                type="number"
                min={0}
                placeholder="Bedrooms"
              />
              <Input
                name="bathrooms"
                type="number"
                min={0}
                placeholder="Bathrooms"
              />
            </>
          ) : null}
          {error ? (
            <p className="text-sm text-destructive sm:col-span-2">{error}</p>
          ) : null}
          <Button type="submit" disabled={pending} className="sm:col-span-2">
            Add service location
          </Button>
        </form>
      ) : null}
    </div>
  );
}
