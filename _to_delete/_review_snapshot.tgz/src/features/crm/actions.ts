"use server";

import { revalidatePath } from "next/cache";
import { isPiiConfigured, prismaPii } from "@/lib/prisma-pii";
import { requireCrmArchive, requireCrmWrite } from "./authz";
import { phoneForStorage } from "@/lib/openphone";
import {
  archiveCustomerSchema,
  createContactSchema,
  createCustomerActivitySchema,
  createCustomerSchema,
  createLeadActivitySchema,
  createLeadSchema,
  createServiceLocationSchema,
  deleteContactSchema,
  deleteLeadSchema,
  deleteServiceLocationSchema,
  promoteLeadSchema,
  updateBillingProfileSchema,
  updateContactSchema,
  updateCustomerSchema,
  updateLeadStatusSchema,
  updateServiceLocationSchema,
} from "./schemas";
import {
  customerTypeDivisionError,
  lockedDivisionSlugForCustomerType,
  normalizeServiceLines,
  normalizeAddressKey,
  rootOrgServiceLocationDefaults,
  validateServiceLines,
  type ServiceLine,
} from "./service-location";

const CLIENTS_PATHS = ["/clients", "/clients/archive"] as const;

function revalidateClients(id?: string) {
  for (const p of CLIENTS_PATHS) revalidatePath(p);
  if (id) {
    revalidatePath(`/clients/${id}`);
    revalidatePath(`/clients/${id}/billing`);
    revalidatePath(`/clients/${id}/contacts`);
    revalidatePath(`/clients/${id}/locations`);
    revalidatePath(`/clients/${id}/notes`);
    revalidatePath(`/clients/${id}/activity`);
    revalidatePath(`/clients/${id}/estimates`);
    revalidatePath(`/clients/${id}/service-tickets`);
    revalidatePath(`/clients/${id}/invoices`);
  }
}

function emptyToNull(v: string | null | undefined) {
  const t = v?.trim();
  return t ? t : null;
}

function defaultBillingType(type: "RESIDENTIAL" | "COMMERCIAL" | "STR") {
  return type === "COMMERCIAL" ? "ENTITY" : "INDIVIDUAL";
}

export type ActionResult =
  | { ok: true; id?: string }
  | { ok: false; error: string };

export async function createCustomer(
  raw: unknown,
): Promise<ActionResult> {
  const user = await requireCrmWrite();
  if (!isPiiConfigured()) {
    return { ok: false, error: "PII database is not configured." };
  }
  const data = createCustomerSchema.parse(raw);

  const division = await prismaPii.division.findUnique({
    where: { id: data.divisionId },
  });
  if (!division) return { ok: false, error: "Unknown division." };

  const lockedSlug = lockedDivisionSlugForCustomerType(data.type);
  const effectiveDivision =
    lockedSlug != null
      ? ((await prismaPii.division.findFirst({ where: { slug: lockedSlug } })) ??
        division)
      : division;
  if (!effectiveDivision) return { ok: false, error: "Unknown division." };

  const pairErr = customerTypeDivisionError(
    data.type,
    effectiveDivision.slug,
  );
  if (pairErr) return { ok: false, error: pairErr };

  const customer = await prismaPii.$transaction(async (tx) => {
    const created = await tx.customer.create({
      data: {
        type: data.type,
        displayName: data.displayName.trim(),
        divisionId: effectiveDivision.id,
        generalEmail: emptyToNull(data.generalEmail),
        mainPhone: emptyToNull(data.mainPhone),
        website: emptyToNull(data.website),
        summary: emptyToNull(data.summary),
        source: emptyToNull(data.source),
        notes: emptyToNull(data.notes),
        hqLine1: emptyToNull(data.hqLine1),
        hqLine2: emptyToNull(data.hqLine2),
        hqCity: emptyToNull(data.hqCity),
        hqRegion: emptyToNull(data.hqRegion),
        hqPostal: emptyToNull(data.hqPostal),
        hqLat: data.hqLat ?? null,
        hqLng: data.hqLng ?? null,
        createdById: user.id,
        billingProfile: {
          create: {
            profileType: defaultBillingType(data.type),
            billingName:
              data.type === "COMMERCIAL" ? data.displayName.trim() : null,
          },
        },
      },
    });

    const first = data.contactFirstName?.trim();
    if (first) {
      await tx.contact.create({
        data: {
          customerId: created.id,
          firstName: first,
          lastName: emptyToNull(data.contactLastName),
          directEmail: emptyToNull(data.contactEmail),
          directPhone: emptyToNull(data.contactPhone),
          roleTag: data.contactRoleTag ?? "CLIENT",
          isPrimary: true,
          isBilling: true,
        },
      });
    }

    await tx.activity.create({
      data: {
        type: "STATUS_CHANGE",
        body: "Customer account created",
        customerId: created.id,
        createdById: user.id,
      },
    });

    return created;
  });

  revalidateClients(customer.id);
  return { ok: true, id: customer.id };
}

export async function updateCustomer(raw: unknown): Promise<ActionResult> {
  await requireCrmWrite();
  if (!isPiiConfigured()) {
    return { ok: false, error: "PII database is not configured." };
  }
  const data = updateCustomerSchema.parse(raw);

  const existing = await prismaPii.customer.findUnique({
    where: { id: data.id },
    include: { division: { select: { id: true, slug: true } } },
  });
  if (!existing) return { ok: false, error: "Customer not found." };

  const nextType = data.type ?? existing.type;
  const lockedSlug = lockedDivisionSlugForCustomerType(nextType);

  let nextDivisionId = data.divisionId ?? existing.divisionId;
  if (lockedSlug != null) {
    const lockedDivision = await prismaPii.division.findFirst({
      where: { slug: lockedSlug },
    });
    if (!lockedDivision) {
      return {
        ok: false,
        error: `Required division (${lockedSlug}) is not configured.`,
      };
    }
    nextDivisionId = lockedDivision.id;
  }

  const nextDivision = await prismaPii.division.findUnique({
    where: { id: nextDivisionId },
  });
  if (!nextDivision) return { ok: false, error: "Unknown division." };
  const pairErr = customerTypeDivisionError(nextType, nextDivision.slug);
  if (pairErr) return { ok: false, error: pairErr };

  await prismaPii.$transaction(async (tx) => {
    const updated = await tx.customer.update({
      where: { id: data.id },
      data: {
        type: data.type,
        displayName: data.displayName?.trim(),
        divisionId: nextDivisionId,
        generalEmail:
          data.generalEmail !== undefined
            ? emptyToNull(data.generalEmail)
            : undefined,
        mainPhone:
          data.mainPhone !== undefined
            ? emptyToNull(data.mainPhone)
            : undefined,
        website:
          data.website !== undefined ? emptyToNull(data.website) : undefined,
        source:
          data.source !== undefined ? emptyToNull(data.source) : undefined,
        notes: data.notes !== undefined ? emptyToNull(data.notes) : undefined,
        summary:
          data.summary !== undefined ? emptyToNull(data.summary) : undefined,
        hqLine1:
          data.hqLine1 !== undefined ? emptyToNull(data.hqLine1) : undefined,
        hqLine2:
          data.hqLine2 !== undefined ? emptyToNull(data.hqLine2) : undefined,
        hqCity:
          data.hqCity !== undefined ? emptyToNull(data.hqCity) : undefined,
        hqRegion:
          data.hqRegion !== undefined ? emptyToNull(data.hqRegion) : undefined,
        hqPostal:
          data.hqPostal !== undefined ? emptyToNull(data.hqPostal) : undefined,
        hqLat: data.hqLat === undefined ? undefined : data.hqLat,
        hqLng: data.hqLng === undefined ? undefined : data.hqLng,
      },
      include: {
        division: { select: { slug: true } },
        contacts: {
          where: { OR: [{ isPrimary: true }, { isBilling: true }] },
          orderBy: [{ isPrimary: "desc" }, { isBilling: "desc" }],
          take: 2,
        },
        billingProfile: true,
        serviceLocations: {
          select: {
            id: true,
            line1: true,
            city: true,
            region: true,
            postalCode: true,
          },
        },
      },
    });

    if (data.useAsBillingAddress) {
      const primary =
        updated.contacts.find((c) => c.isPrimary) ??
        updated.contacts.find((c) => c.isBilling) ??
        updated.contacts[0];
      const billingName =
        primary != null
          ? [primary.firstName, primary.lastName].filter(Boolean).join(" ")
          : updated.displayName;
      const billingEmail =
        primary?.directEmail ?? updated.generalEmail ?? null;
      const billingPhone = primary?.directPhone ?? updated.mainPhone ?? null;

      await tx.billingProfile.upsert({
        where: { rootOrgId: updated.id },
        create: {
          rootOrgId: updated.id,
          profileType: defaultBillingType(updated.type),
          billingName,
          billingEmail,
          billingPhone,
          billingLine1: updated.hqLine1,
          billingLine2: updated.hqLine2,
          billingCity: updated.hqCity,
          billingRegion: updated.hqRegion,
          billingPostal: updated.hqPostal,
          billingLat: updated.hqLat,
          billingLng: updated.hqLng,
          pointOfContactId: primary?.id ?? null,
        },
        update: {
          billingName,
          billingEmail,
          billingPhone,
          billingLine1: updated.hqLine1,
          billingLine2: updated.hqLine2,
          billingCity: updated.hqCity,
          billingRegion: updated.hqRegion,
          billingPostal: updated.hqPostal,
          billingLat: updated.hqLat,
          billingLng: updated.hqLng,
          pointOfContactId: primary?.id ?? undefined,
        },
      });
    }

    if (data.createServiceLocationFromRoot) {
      const line1 = updated.hqLine1?.trim();
      const city = updated.hqCity?.trim();
      const region = updated.hqRegion?.trim();
      const postalCode = updated.hqPostal?.trim();
      if (line1 && city && region && postalCode) {
        const key = normalizeAddressKey({
          line1,
          city,
          region,
          postalCode,
        });
        const exists = updated.serviceLocations.some(
          (loc) =>
            normalizeAddressKey({
              line1: loc.line1,
              city: loc.city,
              region: loc.region,
              postalCode: loc.postalCode,
            }) === key,
        );
        if (!exists) {
          const defaults = rootOrgServiceLocationDefaults({
            customerType: updated.type,
            divisionSlug: updated.division.slug,
          });
          const lines = normalizeServiceLines(
            defaults.classification,
            defaults.serviceLines,
          );
          await tx.serviceLocation.create({
            data: {
              customerId: updated.id,
              siteName: updated.displayName,
              classification: defaults.classification,
              serviceLines: lines,
              line1,
              line2: updated.hqLine2,
              city,
              region,
              postalCode,
              country: "US",
              latitude: updated.hqLat,
              longitude: updated.hqLng,
            },
          });
        }
      }
    }
  });

  revalidateClients(data.id);
  return { ok: true, id: data.id };
}

export async function archiveCustomer(raw: unknown): Promise<ActionResult> {
  await requireCrmArchive();
  if (!isPiiConfigured()) {
    return { ok: false, error: "PII database is not configured." };
  }
  const data = archiveCustomerSchema.parse(raw);
  await prismaPii.customer.update({
    where: { id: data.id },
    data: { archivedAt: new Date() },
  });
  revalidateClients(data.id);
  return { ok: true, id: data.id };
}

export async function restoreCustomer(raw: unknown): Promise<ActionResult> {
  await requireCrmArchive();
  if (!isPiiConfigured()) {
    return { ok: false, error: "PII database is not configured." };
  }
  const data = archiveCustomerSchema.parse(raw);
  await prismaPii.customer.update({
    where: { id: data.id },
    data: { archivedAt: null },
  });
  revalidateClients(data.id);
  return { ok: true, id: data.id };
}

export async function updateBillingProfile(
  raw: unknown,
): Promise<ActionResult> {
  await requireCrmWrite();
  if (!isPiiConfigured()) {
    return { ok: false, error: "PII database is not configured." };
  }
  const data = updateBillingProfileSchema.parse(raw);

  await prismaPii.billingProfile.upsert({
    where: { rootOrgId: data.rootOrgId },
    create: {
      rootOrgId: data.rootOrgId,
      profileType: data.profileType,
      billingName: emptyToNull(data.billingName),
      billingEmail: emptyToNull(data.billingEmail),
      billingPhone: emptyToNull(data.billingPhone),
      billingLine1: emptyToNull(data.billingLine1),
      billingLine2: emptyToNull(data.billingLine2),
      billingCity: emptyToNull(data.billingCity),
      billingRegion: emptyToNull(data.billingRegion),
      billingPostal: emptyToNull(data.billingPostal),
      billingLat: data.billingLat ?? null,
      billingLng: data.billingLng ?? null,
      pointOfContactId: emptyToNull(data.pointOfContactId),
      taxExemptionNumber: emptyToNull(data.taxExemptionNumber),
      taxExemptEntityType: data.taxExemptEntityType ?? null,
      taxExemptCertOnFile: data.taxExemptCertOnFile ?? false,
      smaStatus: data.smaStatus ?? null,
    },
    update: {
      profileType: data.profileType,
      billingName: emptyToNull(data.billingName),
      billingEmail: emptyToNull(data.billingEmail),
      billingPhone: emptyToNull(data.billingPhone),
      billingLine1: emptyToNull(data.billingLine1),
      billingLine2: emptyToNull(data.billingLine2),
      billingCity: emptyToNull(data.billingCity),
      billingRegion: emptyToNull(data.billingRegion),
      billingPostal: emptyToNull(data.billingPostal),
      billingLat: data.billingLat ?? null,
      billingLng: data.billingLng ?? null,
      pointOfContactId: emptyToNull(data.pointOfContactId),
      taxExemptionNumber: emptyToNull(data.taxExemptionNumber),
      taxExemptEntityType: data.taxExemptEntityType ?? null,
      taxExemptCertOnFile: data.taxExemptCertOnFile ?? false,
      smaStatus: data.smaStatus ?? null,
    },
  });

  revalidateClients(data.rootOrgId);
  return { ok: true, id: data.rootOrgId };
}

export async function createContact(raw: unknown): Promise<ActionResult> {
  await requireCrmWrite();
  if (!isPiiConfigured()) {
    return { ok: false, error: "PII database is not configured." };
  }
  const data = createContactSchema.parse(raw);

  const contact = await prismaPii.$transaction(async (tx) => {
    if (data.isPrimary) {
      await tx.contact.updateMany({
        where: { customerId: data.customerId },
        data: { isPrimary: false },
      });
    }
    if (data.isBilling) {
      await tx.contact.updateMany({
        where: { customerId: data.customerId },
        data: { isBilling: false },
      });
    }
    return tx.contact.create({
      data: {
        customerId: data.customerId,
        firstName: data.firstName.trim(),
        lastName: emptyToNull(data.lastName),
        directEmail: emptyToNull(data.directEmail),
        directPhone: emptyToNull(data.directPhone),
        roleTag: data.roleTag ?? null,
        isPrimary: data.isPrimary ?? false,
        isBilling: data.isBilling ?? false,
      },
    });
  });

  revalidateClients(data.customerId);
  return { ok: true, id: contact.id };
}

export async function updateContact(raw: unknown): Promise<ActionResult> {
  await requireCrmWrite();
  if (!isPiiConfigured()) {
    return { ok: false, error: "PII database is not configured." };
  }
  const data = updateContactSchema.parse(raw);
  const existing = await prismaPii.contact.findUnique({
    where: { id: data.id },
  });
  if (!existing) return { ok: false, error: "Contact not found." };

  await prismaPii.$transaction(async (tx) => {
    if (data.isPrimary) {
      await tx.contact.updateMany({
        where: { customerId: existing.customerId, NOT: { id: data.id } },
        data: { isPrimary: false },
      });
    }
    if (data.isBilling) {
      await tx.contact.updateMany({
        where: { customerId: existing.customerId, NOT: { id: data.id } },
        data: { isBilling: false },
      });
    }
    await tx.contact.update({
      where: { id: data.id },
      data: {
        firstName: data.firstName?.trim(),
        lastName:
          data.lastName !== undefined ? emptyToNull(data.lastName) : undefined,
        directEmail:
          data.directEmail !== undefined
            ? emptyToNull(data.directEmail)
            : undefined,
        directPhone:
          data.directPhone !== undefined
            ? emptyToNull(data.directPhone)
            : undefined,
        roleTag: data.roleTag === undefined ? undefined : data.roleTag,
        isPrimary: data.isPrimary,
        isBilling: data.isBilling,
      },
    });
  });

  revalidateClients(existing.customerId);
  return { ok: true, id: data.id };
}

export async function deleteContact(raw: unknown): Promise<ActionResult> {
  await requireCrmWrite();
  if (!isPiiConfigured()) {
    return { ok: false, error: "PII database is not configured." };
  }
  const data = deleteContactSchema.parse(raw);
  const existing = await prismaPii.contact.findUnique({
    where: { id: data.id },
  });
  if (!existing) return { ok: false, error: "Contact not found." };
  await prismaPii.contact.delete({ where: { id: data.id } });
  revalidateClients(existing.customerId);
  return { ok: true };
}

export async function createServiceLocation(
  raw: unknown,
): Promise<ActionResult> {
  await requireCrmWrite();
  if (!isPiiConfigured()) {
    return { ok: false, error: "PII database is not configured." };
  }
  const data = createServiceLocationSchema.parse(raw);
  const lines = normalizeServiceLines(
    data.classification,
    data.serviceLines as ServiceLine[],
  );
  const err = validateServiceLines(data.classification, lines);
  if (err) return { ok: false, error: err };

  const loc = await prismaPii.serviceLocation.create({
    data: {
      customerId: data.customerId,
      siteName: emptyToNull(data.siteName),
      classification: data.classification,
      serviceLines: lines,
      line1: data.line1.trim(),
      line2: emptyToNull(data.line2),
      city: data.city.trim(),
      region: data.region.trim(),
      postalCode: data.postalCode.trim(),
      country: data.country?.trim() || "US",
      latitude: data.latitude ?? null,
      longitude: data.longitude ?? null,
      notes: emptyToNull(data.notes),
      bedrooms: data.bedrooms ?? null,
      bathrooms: data.bathrooms ?? null,
      complexitySelections: data.complexitySelections ?? [],
    },
  });

  revalidateClients(data.customerId);
  return { ok: true, id: loc.id };
}

export async function updateServiceLocation(
  raw: unknown,
): Promise<ActionResult> {
  await requireCrmWrite();
  if (!isPiiConfigured()) {
    return { ok: false, error: "PII database is not configured." };
  }
  const data = updateServiceLocationSchema.parse(raw);
  const existing = await prismaPii.serviceLocation.findUnique({
    where: { id: data.id },
  });
  if (!existing) return { ok: false, error: "Service location not found." };

  const classification = data.classification ?? existing.classification;
  const lines = normalizeServiceLines(
    classification,
    (data.serviceLines as ServiceLine[] | undefined) ??
      (existing.serviceLines as ServiceLine[]),
  );
  const err = validateServiceLines(classification, lines);
  if (err) return { ok: false, error: err };

  await prismaPii.serviceLocation.update({
    where: { id: data.id },
    data: {
      siteName:
        data.siteName !== undefined ? emptyToNull(data.siteName) : undefined,
      classification: data.classification,
      serviceLines: lines,
      line1: data.line1?.trim(),
      line2: data.line2 !== undefined ? emptyToNull(data.line2) : undefined,
      city: data.city?.trim(),
      region: data.region?.trim(),
      postalCode: data.postalCode?.trim(),
      country: data.country?.trim(),
      latitude: data.latitude === undefined ? undefined : data.latitude,
      longitude: data.longitude === undefined ? undefined : data.longitude,
      notes: data.notes !== undefined ? emptyToNull(data.notes) : undefined,
      bedrooms: data.bedrooms === undefined ? undefined : data.bedrooms,
      bathrooms: data.bathrooms === undefined ? undefined : data.bathrooms,
      complexitySelections: data.complexitySelections,
    },
  });

  revalidateClients(existing.customerId);
  return { ok: true, id: data.id };
}

export async function deleteServiceLocation(
  raw: unknown,
): Promise<ActionResult> {
  await requireCrmWrite();
  if (!isPiiConfigured()) {
    return { ok: false, error: "PII database is not configured." };
  }
  const data = deleteServiceLocationSchema.parse(raw);
  const existing = await prismaPii.serviceLocation.findUnique({
    where: { id: data.id },
  });
  if (!existing) return { ok: false, error: "Service location not found." };
  await prismaPii.serviceLocation.delete({ where: { id: data.id } });
  revalidateClients(existing.customerId);
  return { ok: true };
}

export async function createCustomerActivity(
  raw: unknown,
): Promise<ActionResult> {
  const user = await requireCrmWrite();
  if (!isPiiConfigured()) {
    return { ok: false, error: "PII database is not configured." };
  }
  const data = createCustomerActivitySchema.parse(raw);

  const activity = await prismaPii.activity.create({
    data: {
      type: "NOTE",
      body: data.body.trim(),
      customerId: data.customerId,
      serviceLocationId: emptyToNull(data.serviceLocationId),
      createdById: user.id,
    },
  });

  revalidateClients(data.customerId);
  return { ok: true, id: activity.id };
}

const LEADS_PATHS = ["/leads", "/leads/archive"] as const;

function revalidateLeads(id?: string) {
  for (const p of LEADS_PATHS) revalidatePath(p);
  if (id) revalidatePath(`/leads/${id}`);
}

const CLOSED_LEAD_STATUSES = new Set(["WON", "LOST", "DISQUALIFIED"]);

export async function createLead(raw: unknown): Promise<ActionResult> {
  await requireCrmWrite();
  if (!isPiiConfigured()) {
    return { ok: false, error: "PII database is not configured." };
  }
  const data = createLeadSchema.parse(raw);
  const division = await prismaPii.division.findUnique({
    where: { id: data.divisionId },
  });
  if (!division) return { ok: false, error: "Unknown division." };

  const lead = await prismaPii.lead.create({
    data: {
      source: data.source,
      divisionId: data.divisionId,
      name: data.name.trim(),
      email: emptyToNull(data.email),
      phone: phoneForStorage(data.phone),
      company: emptyToNull(data.company),
      message: emptyToNull(data.message),
      budget: emptyToNull(data.budget),
      timeline: emptyToNull(data.timeline),
      division: emptyToNull(data.division),
    },
  });
  revalidateLeads(lead.id);
  revalidatePath("/call-log");
  return { ok: true, id: lead.id };
}

export async function updateLeadStatus(raw: unknown): Promise<ActionResult> {
  const user = await requireCrmWrite();
  if (!isPiiConfigured()) {
    return { ok: false, error: "PII database is not configured." };
  }
  const data = updateLeadStatusSchema.parse(raw);
  const lead = await prismaPii.lead.findUnique({ where: { id: data.id } });
  if (!lead) return { ok: false, error: "Lead not found." };

  const closed = CLOSED_LEAD_STATUSES.has(data.status);
  await prismaPii.$transaction(async (tx) => {
    await tx.lead.update({
      where: { id: data.id },
      data: {
        status: data.status,
        closedAt: closed ? (lead.closedAt ?? new Date()) : null,
      },
    });
    if (data.status !== lead.status) {
      await tx.activity.create({
        data: {
          type: "STATUS_CHANGE",
          body: `Status → ${data.status}`,
          leadId: data.id,
          createdById: user.id,
        },
      });
    }
  });

  revalidateLeads(data.id);
  return { ok: true, id: data.id };
}

/** Hard-delete any lead (spam / not interested). Customer row is kept if promoted. */
export async function deleteLead(raw: unknown): Promise<ActionResult> {
  await requireCrmWrite();
  if (!isPiiConfigured()) {
    return { ok: false, error: "PII database is not configured." };
  }
  const data = deleteLeadSchema.parse(raw);
  const lead = await prismaPii.lead.findUnique({
    where: { id: data.id },
    select: { id: true },
  });
  if (!lead) return { ok: false, error: "Lead not found." };
  await prismaPii.lead.delete({ where: { id: data.id } });
  revalidateLeads();
  revalidatePath("/call-log");
  return { ok: true, id: data.id };
}

export async function createLeadActivity(raw: unknown): Promise<ActionResult> {
  const user = await requireCrmWrite();
  if (!isPiiConfigured()) {
    return { ok: false, error: "PII database is not configured." };
  }
  const data = createLeadActivitySchema.parse(raw);
  const lead = await prismaPii.lead.findUnique({
    where: { id: data.leadId },
    select: { id: true },
  });
  if (!lead) return { ok: false, error: "Lead not found." };

  const activity = await prismaPii.activity.create({
    data: {
      type: "NOTE",
      body: data.body.trim(),
      leadId: data.leadId,
      createdById: user.id,
    },
  });
  revalidateLeads(data.leadId);
  return { ok: true, id: activity.id };
}

export async function promoteLeadToCustomer(
  raw: unknown,
): Promise<ActionResult> {
  const user = await requireCrmWrite();
  if (!isPiiConfigured()) {
    return { ok: false, error: "PII database is not configured." };
  }
  const data = promoteLeadSchema.parse(raw);
  const lead = await prismaPii.lead.findUnique({ where: { id: data.leadId } });
  if (!lead) return { ok: false, error: "Lead not found." };
  if (lead.customerId) return { ok: true, id: lead.customerId };

  const [firstName, ...rest] = lead.name.trim().split(/\s+/);
  const customer = await prismaPii.customer.create({
    data: {
      type: data.type,
      displayName: lead.name.trim(),
      divisionId: lead.divisionId,
      generalEmail: lead.email,
      mainPhone: lead.phone,
      source: `lead:${lead.source}`,
      notes: lead.message,
      createdById: user.id,
      billingProfile: {
        create: {
          profileType: defaultBillingType(data.type),
        },
      },
      contacts: {
        create: {
          firstName: firstName || lead.name.trim(),
          lastName: rest.join(" ") || null,
          directEmail: lead.email,
          directPhone: lead.phone,
          roleTag: "CLIENT",
          isPrimary: true,
        },
      },
    },
  });
  await prismaPii.lead.update({
    where: { id: lead.id },
    data: { customerId: customer.id },
  });

  revalidateLeads(lead.id);
  revalidateClients(customer.id);
  revalidatePath("/call-log");
  return { ok: true, id: customer.id };
}
